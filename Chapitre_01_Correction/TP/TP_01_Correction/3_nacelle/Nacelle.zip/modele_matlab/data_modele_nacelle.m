ki_tangage=1000;
kp_tangage=1000;
kd_tangage=0;
echelon_tangage=20;
ki_roulis=1000;
kp_roulis=0;
kd_roulis=0;
echelon_roulis=0;
